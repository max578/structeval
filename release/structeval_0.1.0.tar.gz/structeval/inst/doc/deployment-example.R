## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(structeval)

## -----------------------------------------------------------------------------
table1 <- data.frame(
  field = c(
    "First Primary Diagnosis", "First Primary Histology",
    "First Primary Overall Stage", "Treatment Drugs",
    "Biomarker Test Results"
  ),
  type = c("scalar", "scalar", "scalar", "list", "list"),
  cor = c(154, 124, 88, 352, 301),
  inc = c(3, 5, 0, 0, 0),
  mis = c(1, 1, 6, 40, 41),
  spu = c(2, 0, 8, 55, 16),
  tn = c(40, 70, 98, NA, NA)
)
table1

## -----------------------------------------------------------------------------
expand <- function(row) {
  outcome <- c("cor", "inc", "mis", "spu", "tn")
  times <- unlist(row[outcome])
  times[is.na(times)] <- 0
  lab <- rep(outcome, times)
  m <- vapply(outcome, function(o) as.integer(lab == o), integer(length(lab)))
  data.frame(
    note = as.character(seq_along(lab)), field = row$field, type = row$type,
    m
  )
}
counts <- do.call(rbind, lapply(seq_len(nrow(table1)), function(i) {
  expand(table1[i, ])
}))
scalar_fields <- table1$field[1:3]
list_fields <- table1$field[4:5]

## -----------------------------------------------------------------------------
est <- metrics(counts, metric = c("precision", "recall", "f1"),
  method = "naive_wilson")
spec <- metrics(counts, field = scalar_fields, metric = "specificity")
point <- rbind(est, spec)[, c("field", "metric", "estimate")]
point$percent <- round(100 * point$estimate, 1)
point[order(point$field), c("field", "metric", "percent")]

## -----------------------------------------------------------------------------
published <- data.frame(
  field = rep(scalar_fields, each = 4),
  metric = rep(c("precision", "recall", "f1", "specificity"), 3),
  published = c(
    "94.1-99.4", "94.8-99.4", "94.7-99.1", "87.8-100",
    "92.4-99.2", "91.4-98.5", "92.0-98.8", "100-100",
    "85.7-96.8", "88.2-97.2", "88.4-96.2", "87.0-97.1"
  )
)
sc <- metrics(counts, field = scalar_fields,
  metric = c("precision", "recall", "f1", "specificity"), seed = 2026)
sc$interval <- sprintf("%.1f-%.1f", 100 * sc$lower, 100 * sc$upper)
merge(sc[, c("field", "metric", "method", "interval", "boundary")],
  published, by = c("field", "metric"), sort = FALSE)

## -----------------------------------------------------------------------------
li <- metrics(counts, field = list_fields,
  metric = c("precision", "recall", "f1"), method = "naive_wilson")
li$published_lower <- c(80.7, 83.2, 83.4, 90.3, 82.4, 87.3) / 100
li$published_upper <- c(91.6, 95.4, 92.1, 98.4, 92.8, 94.7) / 100
li$naive <- sprintf("%.1f-%.1f", 100 * li$lower, 100 * li$upper)
li$published <- sprintf("%.1f-%.1f", 100 * li$published_lower,
  100 * li$published_upper)
li$width_ratio <- round(
  (li$upper - li$lower) / (li$published_upper - li$published_lower), 2
)
li[, c("field", "metric", "naive", "published", "width_ratio")]

## -----------------------------------------------------------------------------
tt <- test_threshold(counts, rep(scalar_fields, each = 3),
  metric = rep(c("precision", "recall", "specificity"), 3), theta0 = 0.90)
tt$lower <- round(tt$lower, 3)
tt$p_value <- signif(tt$p_value, 2)
tt[, c("field", "metric", "estimate", "lower", "p_value", "reject")]

## -----------------------------------------------------------------------------
li$certifies_090 <- li$published_lower > 0.90
li[, c("field", "metric", "published", "certifies_090")]

## -----------------------------------------------------------------------------
asym <- do.call(rbind, lapply(list_fields, function(f) {
  test_asymmetry(counts, f, method = "binomial")
}))
asym$estimate <- round(asym$estimate, 3)
asym$p_value <- signif(asym$p_value, 2)
asym[, c("field", "estimate", "n", "p_value", "reject")]

## -----------------------------------------------------------------------------
sim <- simulate_counts(n = 100, theta = 0.88, m = 4, rho = 0.2,
  spu_ratio = 0.4, type = "list", seed = 2026)
rbind(
  test_asymmetry(sim, "field", method = "signflip", seed = 1),
  test_asymmetry(sim, "field", method = "cluster_t"),
  test_asymmetry(sim, "field", method = "binomial")
)[, c("method", "estimate", "p_value", "reject")]
test_threshold(sim, "field", "f1", theta0 = 0.80, seed = 1)

## -----------------------------------------------------------------------------
rbind(
  n_threshold(0.90, 0.95),
  n_threshold(0.90, 0.95, prevalence = 158 / 200),
  n_threshold(0.85, 0.90, m = 4, rho = 0.2)
)[, c("theta0", "theta1", "m", "rho", "prevalence", "deff", "n_units",
  "n_present", "n_notes")]

## -----------------------------------------------------------------------------
min_certifiable(50, 0.90)

